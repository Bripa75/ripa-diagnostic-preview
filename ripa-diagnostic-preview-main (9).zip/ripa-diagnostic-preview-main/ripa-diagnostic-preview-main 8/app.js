// app.js — Adaptive 20-item path (10 Math → 10 English). Grades 2–8.

import { DIFF, MATH_ITEMS, PASSAGES, LANG_ITEMS } from './bank.js';
import { standardMetaForItem } from './standards.js';

// Supabase (for access codes)
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./supabase-config.js";

const _looksLikePlaceholder = (v) =>
  !v || typeof v !== "string" || v.includes("PASTE_YOUR_SUPABASE");

const supabase =
  !_looksLikePlaceholder(SUPABASE_URL) &&
  !_looksLikePlaceholder(SUPABASE_ANON_KEY) &&
  SUPABASE_URL.startsWith("http") &&
  SUPABASE_ANON_KEY.length > 20
    ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    : null;

let currentAccessCode = null;

/* ---------------- Config ---------------- */
const TARGET = { math: 10, english: 10 }; // per student

const NOTIFY_THROTTLE_MS = 2 * 60 * 1000; // 2 minutes
const NOTIFY_TS_KEY = "ripa_notify_last_ts_v1";

/* ---------------- Rotation (per grade/phase) ---------------- */
const SEEN_PREFIX = "ripa_seen_v1";
function loadSeen(grade, phase){
  try { return new Set(JSON.parse(localStorage.getItem(`${SEEN_PREFIX}_${grade}_${phase}`))||[]); }
  catch { return new Set(); }
}
function addSeen(grade, phase, id){
  const key = `${SEEN_PREFIX}_${grade}_${phase}`;
  const cur = loadSeen(grade, phase);
  cur.add(id);
  localStorage.setItem(key, JSON.stringify([...cur]));
}

/* ---------------- Helpers ---------------- */
const between = (n,a,b)=> n>=a && n<=b;
const pickOne = (arr)=> arr[Math.floor(Math.random()*arr.length)];
const clamp = (v,a,b)=> Math.max(a, Math.min(b,v));
const pct = (c,t)=> t ? Math.round(100*c/t) : 0;

/* ---------------- Access Code (Supabase) ---------------- */
function showAccessError(msg){
  const el = document.getElementById('accessError');
  if (!el) return;
  el.style.display = msg ? 'block' : 'none';
  el.textContent = msg || '';
}

// ✅ Validate+consume in ONE call using your SQL function redeem_access_code(code_input text) returns boolean
async function redeemAccessCode(code){
  if (!supabase) {
    return { ok:false, reason:"Setup required: Supabase not configured. Check supabase-config.js" };
  }

  const cleaned = (code || "").trim().toUpperCase();
  if (!cleaned) return { ok:false, reason:"Please enter your access code." };

  // Optional: your generator produces 8 hex chars. Keeps input clean.
  if (!/^[A-F0-9]{8}$/.test(cleaned)) {
    return { ok:false, reason:"That access code format looks wrong." };
  }

  const { data, error } = await supabase.rpc("redeem_access_code", { code_input: cleaned });

  if (error) {
    console.error("redeem_access_code rpc error:", error);
    return { ok:false, reason:"Access code check failed (database)." };
  }

  // data should be true/false
  if (data !== true) {
    return { ok:false, reason:"Code invalid, expired, or already used." };
  }

  return { ok:true, code: cleaned };
}

function flattenPassageQuestion(p, q, diffTag){
  const grade = Number((p.id.match(/^G(\d+)-/)||[])[1] || 0);
  return {
    id: `E-${p.id}-${q.id}`,
    domain: p.type,     // RL or RI
    diff: diffTag,
    stem: q.stem,
    choices: q.choices,
    answer: q.answer,
    context: p.text,
    grade,
    qid: q.id
  };
}
function qIndexToDiff(i){ return i<=1 ? DIFF.CORE : i<=3 ? DIFF.ON : DIFF.STRETCH; }

/* Build grade-scoped pools */
function buildPools(grade){
  const nextGrade = Math.min(8, grade + 1);

  const mathByDiff = {
    [DIFF.CORE]:    MATH_ITEMS.filter(it => it.diff===DIFF.CORE    && between(grade, it.grade_min, it.grade_max)),
    [DIFF.ON]:      MATH_ITEMS.filter(it => it.diff===DIFF.ON      && between(grade, it.grade_min, it.grade_max)),
    [DIFF.STRETCH]: MATH_ITEMS.filter(it => it.diff===DIFF.STRETCH && between(grade, it.grade_min, it.grade_max)),
  };

  if (nextGrade !== grade && grade >= 6){
    const nextMath = MATH_ITEMS.filter(it => between(nextGrade, it.grade_min, it.grade_max));
    mathByDiff[DIFF.STRETCH].push(...nextMath.map(it => ({ ...it, diff: DIFF.STRETCH })));
  }

  const englishPool = { [DIFF.CORE]:[], [DIFF.ON]:[], [DIFF.STRETCH]:[] };
  PASSAGES.forEach(p=>{
    if (!between(grade, p.grade_band[0], p.grade_band[1])) return;
    (p.questions||[]).forEach((q, idx)=>{
      const diff = qIndexToDiff(idx);
      englishPool[diff].push(flattenPassageQuestion(p, q, diff));
    });
  });
  LANG_ITEMS.forEach(it=>{
    if (!between(grade, it.grade_min, it.grade_max)) return;
    englishPool[it.diff].push({
      id:`E-LANG-${it.id}`,
      domain:"LANG",
      diff:it.diff,
      stem:it.stem,
      choices:it.choices,
      answer:it.answer,
      context:null,
      standard_code: it.standard_code,
      skill_tag: it.skill_tag
    });
  });

  if (nextGrade !== grade && grade >= 6){
    const nextLang = LANG_ITEMS.filter(it => between(nextGrade, it.grade_min, it.grade_max));
    englishPool[DIFF.STRETCH].push(...nextLang.map(it => ({
      id:`E-LANG-${it.id}`,
      domain:"LANG",
      diff:DIFF.STRETCH,
      stem:it.stem,
      choices:it.choices,
      answer:it.answer,
      context:null
    })));
  }

  return { mathByDiff, englishPool };
}

/* ---------------- Difficulty buffer: 2-in-a-row to move ---------------- */
function adjustDiff2(curDiff, buf, isCorrect){
  const nextBuf = isCorrect ? Math.min(2, buf + 1) : Math.max(-2, buf - 1);
  if (nextBuf >= 2)  return { diff: (curDiff===DIFF.CORE ? DIFF.ON : DIFF.STRETCH), buf: 0 };
  if (nextBuf <= -2) return { diff: (curDiff===DIFF.STRETCH ? DIFF.ON : DIFF.CORE), buf: 0 };
  return { diff: curDiff, buf: nextBuf };
}

/* ---------------- Coverage plans ---------------- */
function buildMathPlan(grade){
  const templates = {
    2: ['ALG','NO','MD','NO','ALG','FR','NO','MD','GEOM','FR'],
    3: ['ALG','NO','FR','ALG','MD','NO','FR','ALG','GEOM','MD'],
    4: ['NO','ALG','FR','NO','MD','FR','ALG','GEOM','NO','MD'],
    5: ['NO','FR','NO','ALG','FR','MD','NO','GEOM','MD','FR']
  };
  const plan = [...(templates[grade] || ['NO','FR','ALG','GEOM','MD','NO','FR','ALG','GEOM','MD'])];
  for (let i = plan.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [plan[i], plan[j]] = [plan[j], plan[i]];
  }
  for (let i=1; i<plan.length; i++){
    if (plan[i] === plan[i-1]){
      const swapWith = (i+1 < plan.length) ? i+1 : i-2;
      if (swapWith >=0 && swapWith < plan.length){
        [plan[i], plan[swapWith]] = [plan[swapWith], plan[i]];
      }
    }
  }
  return plan;
}

function buildEnglishPlan(grade){
  const templates = {
    2: ['RL','RI','LANG','RL','RI','LANG','RL','RI','LANG','RL'],
    3: ['RL','RI','LANG','RL','RI','LANG','RL','RI','LANG','RI'],
    4: ['RL','RI','RL','RI','LANG','RL','RI','LANG','RL','RI'],
    5: ['RL','RI','RL','RI','LANG','RL','RI','LANG','RL','RI']
  };
  const plan = [...(templates[grade] || ['RL','RL','RL','RL','RI','RI','RI','RI','LANG','LANG'])];
  for (let i = plan.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [plan[i], plan[j]] = [plan[j], plan[i]];
  }
  for (let i=1; i<plan.length; i++){
    if (plan[i] === plan[i-1]){
      const swapWith = (i+1 < plan.length) ? i+1 : i-2;
      if (swapWith >=0 && swapWith < plan.length){
        [plan[i], plan[swapWith]] = [plan[swapWith], plan[i]];
      }
    }
  }
  return plan;
}

/* ---------------- Strand/domain-aware picker with fallback ---------------- */
function takeFromWithKey(poolMap, wantDiff, usedIds, seenSet, keyField, keyValue){
  const order = wantDiff===DIFF.CORE ? [DIFF.CORE, DIFF.ON]
              : wantDiff===DIFF.ON   ? [DIFF.ON, DIFF.CORE, DIFF.STRETCH]
              :                        [DIFF.STRETCH, DIFF.ON];

  for (const d of order){
    const pool = (poolMap[d] || []).filter(x =>
      !usedIds.has(x.id) && !seenSet.has(x.id) && (keyValue ? x[keyField]===keyValue : true)
    );
    if (pool.length) return { item: pickOne(pool), usedDiff: d };
  }
  for (const d of order){
    const pool = (poolMap[d] || []).filter(x =>
      !usedIds.has(x.id) && (keyValue ? x[keyField]===keyValue : true)
    );
    if (pool.length) return { item: pickOne(pool), usedDiff: d };
  }
  return { item: null, usedDiff: wantDiff };
}

/* ---------------- Dev safety: validate item integrity ---------------- */
function validateItem(item){
  if (!item) return true;
  const choices = item.choices || [];
  if (choices.length !== 4) return false;
  const set = new Set(choices.map(c=>String(c)));
  if (set.size !== 4) return false;
  const correct = String(item.answer);
  const correctCount = choices.filter(c=>String(c)===correct).length;
  return correctCount === 1;
}

/* ---------------- Runtime State ---------------- */
let state = null;

/* ---------------- Email notify helper (Formspree hidden form) ---------------- */
function notifyViaFormspree({ grade, mathPct, engPct, conf, mathLevel, elaLevel, summary }) {
  const form = document.getElementById('notifyForm');
  if (!form) return;

  try {
    const last = Number(localStorage.getItem(NOTIFY_TS_KEY) || 0);
    const now = Date.now();
    if (now - last < NOTIFY_THROTTLE_MS) {
      console.info("Too soon to notify again; skipping Formspree submit.");
      return;
    }
    localStorage.setItem(NOTIFY_TS_KEY, String(now));
  } catch {}

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = String(val); };
  set('notify-grade', grade);
  set('notify-mathPct', mathPct);
  set('notify-engPct', engPct);
  set('notify-confidence', conf);
  set('notify-mathLevel', (mathLevel?.toFixed ? mathLevel.toFixed(1) : mathLevel));
  set('notify-elaLevel', (elaLevel?.toFixed ? elaLevel.toFixed(1) : elaLevel));
  set('notify-summary', summary);
  set('notify-student', state?.studentName || '');
  set('notify-parentEmail', state?.parentEmail || '');

  try { form.submit(); } catch (e) { console.warn('Formspree submit failed', e); }
}

/* ---------------- Init ---------------- */
function initState(grade, studentName, parentEmail){
  const pools = buildPools(grade);
  state = {
    grade,
    studentName: studentName || "",
    parentEmail: parentEmail || "",
    phase: "math",
    targetInPhase: TARGET.math,
    answeredInPhase: 0,
    totalTarget: TARGET.math + TARGET.english,

    mathDiff: DIFF.ON,
    engDiff: DIFF.ON,

    usedIds: new Set(),
    correct: 0,
    total: 0,
    strands: { NO:[0,0], FR:[0,0], ALG:[0,0], GEOM:[0,0], MD:[0,0], RL:[0,0], RI:[0,0], LANG:[0,0] },
    standards: {},
    skills: {},

    pools,
    current: null,
    lastDiffs: [],

    mathBuf: 0,
    engBuf: 0,
    mathPlan: buildMathPlan(grade),
    mathPlanIdx: 0,
    engPlan: buildEnglishPlan(grade),
    engPlanIdx: 0
  };
}

/* ---------------- DOM helpers ---------------- */
function el(tag, attrs={}, children=[]){
  const node = document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=>{
    if (k==="class") node.className = v;
    else if (k.startsWith("on") && typeof v==="function") {
      node.addEventListener(k.substring(2).toLowerCase(), v);
    } else node.setAttribute(k,v);
  });
  (Array.isArray(children)?children:[children]).forEach(c=> node.append(c instanceof Node ? c : document.createTextNode(String(c))));
  return node;
}

// ✅ keep only THIS progress function
function setProgress(){
  const pf = document.getElementById("progFill");
  if (!pf || !state) return;
  const ratio = state.total / state.totalTarget;
  pf.style.width = `${Math.min(100, Math.round(ratio*100))}%`;
}

/* ---------------- Render current ---------------- */
function renderCurrent(container){
  container.innerHTML = "";
  if (!state) return;

  const isMath = state.phase === "math";
  const domainLabel = isMath ? "Math" : "English";

  container.append(
    el("div",{class:"label"}, `${domainLabel} Question ${state.answeredInPhase+1} of ${state.targetInPhase}`)
  );

  const seen = loadSeen(state.grade, state.phase);

  let picked;
  if (isMath){
    const wantStrand = state.mathPlan[state.mathPlanIdx] || "NO";
    picked = takeFromWithKey(state.pools.mathByDiff, state.mathDiff, state.usedIds, seen, "strand", wantStrand);
  } else {
    const wantDomain = state.engPlan[state.engPlanIdx] || "RL";
    picked = takeFromWithKey(state.pools.englishPool, state.engDiff, state.usedIds, seen, "domain", wantDomain);
  }

  const item = picked.item;
  if (!item){ advancePhaseOrFinish(container); return; }

  if (!validateItem(item)){
    const retry = isMath
      ? takeFromWithKey(state.pools.mathByDiff, state.mathDiff, state.usedIds, new Set(), "strand", state.mathPlan[state.mathPlanIdx])
      : takeFromWithKey(state.pools.englishPool, state.engDiff, state.usedIds, new Set(), "domain", state.engPlan[state.engPlanIdx]);
    if (!retry.item){ advancePhaseOrFinish(container); return; }
    state.current = retry.item;
  } else {
    state.current = item;
  }

  if (isMath && !["NO","FR","ALG","GEOM","MD"].includes(state.current.strand)){
    advancePhaseOrFinish(container); return;
  }
  if (!isMath && !["RL","RI","LANG"].includes(state.current.domain)){
    advancePhaseOrFinish(container); return;
  }

  state.usedIds.add(state.current.id);
  addSeen(state.grade, state.phase, state.current.id);

  if (!isMath && state.current.context){
    container.append(el("div",{class:"passage"}, state.current.context));
  }

  const li = el("div",{class:"item"});
  li.append(el("div",{class:"qtext"}, state.current.stem));

  const wrap = el("div",{class:"choices"});
  (state.current.choices||[]).forEach(c=>{
    wrap.append(el("button",{class:"btn", onClick: ()=>answer(c)}, c));
  });
  li.append(wrap);
  container.append(li);

  if (isMath){
    state.mathPlanIdx = Math.min(state.mathPlanIdx + 1, state.targetInPhase - 1);
  } else {
    state.engPlanIdx = Math.min(state.engPlanIdx + 1, state.targetInPhase - 1);
  }
}

/* ---------------- Answer (adaptive with hysteresis) ---------------- */
function diffToScore(d){ return d===DIFF.CORE?1:d===DIFF.ON?2:3; }

function answer(chosen){
  if (!state || !state.current) return;
  const item = state.current;
  const isCorrect = String(chosen) === String(item.answer);
  state.total++; if (isCorrect) state.correct++;

  if (state.phase==="math"){
    const strand = item.strand || "NO";
    state.strands[strand][1]++; if (isCorrect) state.strands[strand][0]++;
    const upd = adjustDiff2(state.mathDiff, state.mathBuf, isCorrect);
    state.mathDiff = upd.diff; state.mathBuf = upd.buf;
    state.lastDiffs.push(diffToScore(state.mathDiff));
  } else {
    const dom = item.domain || "RL";
    state.strands[dom][1]++; if (isCorrect) state.strands[dom][0]++;
    const upd = adjustDiff2(state.engDiff, state.engBuf, isCorrect);
    state.engDiff = upd.diff; state.engBuf = upd.buf;
    state.lastDiffs.push(diffToScore(state.engDiff));
  }

  const meta = standardMetaForItem(item, state.grade);
  if (meta?.code){
    if (!state.standards[meta.code]) state.standards[meta.code] = { correct:0, total:0, label:meta.label, skill:meta.skill };
    state.standards[meta.code].total++;
    if (isCorrect) state.standards[meta.code].correct++;
  }
  if (meta?.skill){
    const key = String(meta.skill);
    if (!state.skills[key]) state.skills[key] = { correct:0, total:0, standards:new Set() };
    state.skills[key].total++;
    if (isCorrect) state.skills[key].correct++;
    if (meta.code) state.skills[key].standards.add(meta.code);
  }

  state.answeredInPhase++;
  setProgress();

  const container = document.getElementById("mount");
  if (state.answeredInPhase >= state.targetInPhase) advancePhaseOrFinish(container);
  else renderCurrent(container);
}

function advancePhaseOrFinish(container){
  if (state.phase==="math"){
    state.phase = "english";
    state.targetInPhase = TARGET.english;
    state.answeredInPhase = 0;
    renderCurrent(container);
  } else {
    finishTest();
  }
}

/* ---------------- Report helpers ---------------- */
function levelForPct(p){
  if (p >= 85) return {level:4, label:"Exceeds Grade Level"};
  if (p >= 70) return {level:3, label:"On Grade Level"};
  if (p >= 50) return {level:2, label:"Approaching Grade Level"};
  return {level:1, label:"Below Grade Level"};
}
function estimateGradeLevel(pctScore, gradeRef){
  const gl = gradeRef - 0.5 + (pctScore/100);
  return Math.round(gl*10)/10;
}
function confidencePct(mathPct, engPct){
  const completeness = state.total / state.totalTarget;
  const trend = clamp((state.lastDiffs.slice(-6).reduce((a,b)=>a+b,0)/ (6*3)) || 0, 0, 1);
  const separation = (Math.abs(mathPct-50) + Math.abs(engPct-50)) / 100;
  const raw = 0.35*completeness + 0.35*trend + 0.30*separation;
  return Math.round(clamp(40 + raw*60, 40, 95));
}
const TAGS = {
  NO:["place-value","integers"],
  FR:["fractions","percent"],
  ALG:["equations","functions"],
  GEOM:["geometry","area"],
  MD: ["data","measurement"],
  RL:["reading","theme"],
  RI:["reading","main-idea"],
  LANG:["vocab","conventions"]
};

function strengthsAndPriorities(s){
  const all = Object.entries(s).map(([k,[c,t]])=>({k, p: pct(c,t), t}));
  const strengths = all.filter(x=>x.t>0).sort((a,b)=> b.p-a.p).slice(0,5);
  const priorities = all.filter(x=>x.t>0).sort((a,b)=> a.p-b.p).slice(0,4);
  const chip = (arr)=> [...new Set(arr.flatMap(x=>TAGS[x.k]||[x.k]))].slice(0,8);
  return { strengths: chip(strengths), priorities: chip(priorities) };
}

function summarizeStandards(standards){
  return Object.entries(standards || {}).map(([code, obj]) => ({
    code,
    label: obj.label || code,
    skill: obj.skill || code,
    correct: obj.correct || 0,
    total: obj.total || 0,
    pct: pct(obj.correct || 0, obj.total || 0)
  })).sort((a,b)=> (a.pct - b.pct) || (b.total - a.total));
}

function summarizeSkills(skills){
  return Object.entries(skills || {}).map(([skill, obj]) => ({
    skill,
    correct: obj.correct || 0,
    total: obj.total || 0,
    pct: pct(obj.correct || 0, obj.total || 0),
    standards: [...(obj.standards || [])]
  })).sort((a,b)=> (a.pct - b.pct) || (b.total - a.total));
}

function renderMetricList(items, emptyText){
  if (!items.length) return `<div class="mini">${emptyText}</div>`;
  return `<div style="display:grid;gap:8px">${items.map(x => `
    <div style="padding:10px 12px;border:1px solid var(--stroke);border-radius:12px;background:rgba(255,255,255,.03)">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
        <div>
          <div style="font-weight:700">${x.code ? `${x.code} — ` : ''}${x.skill || x.label}</div>
          ${x.label && x.code ? `<div class="mini">${x.label}</div>` : ''}
        </div>
        <div style="font-weight:800">${x.pct}%</div>
      </div>
      <div class="mini" style="margin-top:4px">${x.correct}/${x.total} correct</div>
    </div>`).join('')}</div>`;
}

function ensureReportStyles(){
  if (document.getElementById("reportStyles")) return;
  const css = `
  .report-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
  @media (max-width: 900px){.report-grid{grid-template-columns:1fr}}
  .statCard{background:var(--glass);border:1px solid var(--stroke);border-radius:14px;padding:14px}
  .statCard .big{font-size:28px;font-weight:800}
  .chipRow{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
  .chip{padding:6px 10px;border-radius:999px;border:1px solid var(--stroke);background:rgba(255,255,255,.05);font-weight:600}
  .btnGhost{padding:10px 12px;border-radius:12px;border:1px solid var(--stroke);background:rgba(255,255,255,.04);cursor:pointer}
  .mini{font-size:12px;color:var(--muted)}
  .sectionTitle{font-size:16px;font-weight:800;margin:0 0 8px}
  .twoCol{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  @media (max-width: 900px){.twoCol{grid-template-columns:1fr}}
  `;
  const tag = document.createElement("style");
  tag.id = "reportStyles"; tag.innerText = css;
  document.head.appendChild(tag);
}

/* ---------------- Finish & render report ---------------- */
function finishTest(){
  const mount = document.getElementById("mount");
  mount.innerHTML = "";
  mount.append(el("p",{class:"examMuted"},"Test complete. See Instant Report below."));

  const pf = document.getElementById("progFill");
  if (pf) pf.style.width = "100%";

  const s = state.strands;
  const mathC = ["NO","FR","ALG","GEOM","MD"].reduce((sum,k)=>sum + (s[k]?.[0]||0), 0);
  const mathT = ["NO","FR","ALG","GEOM","MD"].reduce((sum,k)=>sum + (s[k]?.[1]||0), 0);
  const engC  = ["RL","RI","LANG"].reduce((sum,k)=>sum + (s[k]?.[0]||0), 0);
  const engT  = ["RL","RI","LANG"].reduce((sum,k)=>sum + (s[k]?.[1]||0), 0);

  const mathPct = pct(mathC, mathT);
  const engPct  = pct(engC, engT);
  const mathLevel = levelForPct(mathPct);
  const engLevel  = levelForPct(engPct);
  const curMathGL = estimateGradeLevel(mathPct, state.grade);
  const curEngGL  = estimateGradeLevel(engPct,  state.grade);
  const conf = confidencePct(mathPct, engPct);
  const { strengths, priorities } = strengthsAndPriorities(s);

  const standardRows = summarizeStandards(state.standards);
  const weakestStandards = standardRows.slice(0, 6);
  const strongestStandards = [...standardRows].sort((a,b)=> b.pct-a.pct || b.total-a.total).slice(0, 4);
  const weakestSkills = summarizeSkills(state.skills).slice(0, 6);

  ensureReportStyles();

  const report = document.getElementById("report");
  report.innerHTML = `
    <div class="title">Instant Report</div>
    <p class="examMuted">Estimates by domain, confidence, skill performance, and NY-aligned standards details for Grades 2–5.</p>

    <div class="report-grid" style="margin-top:8px">
      <div class="statCard">
        <div class="label">Math level (current)</div>
        <div class="big">${curMathGL.toFixed(1)}</div>
        <div class="mini">Level ${mathLevel.level} — ${mathLevel.label}</div>
      </div>
      <div class="statCard">
        <div class="label">ELA level (current)</div>
        <div class="big">${curEngGL.toFixed(1)}</div>
        <div class="mini">Level ${engLevel.level} — ${engLevel.label}</div>
      </div>
      <div class="statCard">
        <div class="label">Overall confidence</div>
        <div class="big">${conf}%</div>
      </div>

      <div class="statCard">
        <div class="label">Math expected</div>
        <div class="big">${state.grade.toFixed(1)}</div>
        <div class="mini">${Math.abs(curMathGL - state.grade) <= 0.2 ? "On track (±0.2)" : (curMathGL > state.grade ? "Above" : "Below")}</div>
      </div>
      <div class="statCard">
        <div class="label">ELA expected</div>
        <div class="big">${state.grade.toFixed(1)}</div>
        <div class="mini">${Math.abs(curEngGL - state.grade) <= 0.2 ? "On track (±0.2)" : (curEngGL > state.grade ? "Above" : "Below")}</div>
      </div>
      <div class="statCard">
        <div class="label">Grade reference</div>
        <div class="big">Grade ${state.grade}</div>
      </div>
    </div>

    <div class="statCard" style="margin-top:12px">
      <div class="label">Strengths</div>
      <div class="chipRow">${strengths.map(t=>`<span class="chip">${t}</span>`).join("")}</div>
      <div class="label" style="margin-top:10px">Priorities</div>
      <div class="chipRow">${priorities.map(t=>`<span class="chip">${t}</span>`).join("")}</div>
    </div>

    <div class="twoCol" style="margin-top:12px">
      <div class="statCard">
        <div class="sectionTitle">Performance by Skill</div>
        ${renderMetricList(weakestSkills, 'No skill-level data yet.')}
      </div>
      <div class="statCard">
        <div class="sectionTitle">Priority Standards</div>
        ${renderMetricList(weakestStandards, 'No standards-level data yet.')}
      </div>
    </div>

    <div class="statCard" style="margin-top:12px">
      <label class="label" style="display:flex;align-items:center;gap:8px">
        <input type="checkbox" id="showStd"> Show standards details
      </label>
      <div id="stdBox" style="display:none;margin-top:8px">
        <div class="twoCol">
          <div>
            <div class="sectionTitle">Lowest current standards</div>
            ${renderMetricList(weakestStandards, 'No standards-level data yet.')}
          </div>
          <div>
            <div class="sectionTitle">Strongest current standards</div>
            ${renderMetricList(strongestStandards, 'No standards-level data yet.')}
          </div>
        </div>
      </div>
    </div>

    <div class="statCard" style="margin-top:12px">
      <div class="title" style="margin:0 0 6px">Action Plan — Next 1–2 Weeks</div>
      ${renderActionPlan(s, weakestStandards)}
      <p class="examMuted" style="margin-top:8px">Structure: Mini-lesson (8–10m) → Guided (15m) → Independent (15m) → 2–3 question exit ticket.</p>
    </div>

    <div class="examMuted" style="margin-top:12px">Mini-FAQ: Grades 2–8 • Length: 20 adaptive questions • Private: runs in the browser; only results you submit are saved.</div>
  `;

  const cb = document.getElementById("showStd");
  const box = document.getElementById("stdBox");
  cb?.addEventListener("change", ()=> box.style.display = cb.checked ? "block" : "none");

  const summary = `Diagnostic complete | Grade: ${state.grade} | Math: ${mathPct}% (level ${curMathGL.toFixed(1)}) | ELA: ${engPct}% (level ${curEngGL.toFixed(1)}) | Confidence: ${conf}%`;
  notifyViaFormspree({
    grade: state.grade,
    mathPct,
    engPct,
    conf,
    mathLevel: curMathGL,
    elaLevel: curEngGL,
    summary
  });
}

function renderActionPlan(strandScores, weakestStandards=[]){
  const keysMath = ["NO","FR","ALG","GEOM","MD"];
  const keysEng  = ["RL","RI","LANG"].filter(k=> (strandScores[k]?.[1]||0)>0);

  const rank = (keys)=> keys
    .map(k=>({k, p: pct(strandScores[k][0], strandScores[k][1])}))
    .sort((a,b)=> a.p - b.p)
    .slice(0,2);

  const tips = {
    NO: "Use quick place-value checks, mental math, and standard algorithm practice with explanation.",
    FR: "Use visual models first, then move to symbolic fraction operations and comparison work.",
    ALG:"Translate words into equations or patterns, then solve with step-by-step reasoning.",
    GEOM:"Sketch shapes, label attributes, and connect vocabulary to visual examples.",
    MD: "Practice conversions, time, area, perimeter, or volume with real-world contexts.",
    RL: "Reread key parts, identify the central lesson or event, and cite story details.",
    RI: "Annotate headings and facts, then connect evidence back to the main idea.",
    LANG:"Use short edit drills focused on grammar, punctuation, and word meaning in context."
  };

  const m = rank(keysMath).map(x=>`<li><b>${x.k}</b> — ${x.p}%: ${tips[x.k]}</li>`).join("");
  const e = rank(keysEng).map(x=>`<li><b>${x.k}</b> — ${x.p}%: ${tips[x.k]}</li>`).join("");
  const std = weakestStandards.slice(0,3).map(x=>`<li><b>${x.code}</b> — ${x.skill}: ${x.label}</li>`).join("");

  return `
    <div class="label">Math Focus</div>
    <ol style="margin:4px 0 10px 18px">${m}</ol>
    <div class="label">English Focus</div>
    <ol style="margin:4px 0 10px 18px">${e || "<li>Collect more English items to refine focus.</li>"}</ol>
    <div class="label">Standards to target first</div>
    <ol style="margin:4px 0 0 18px">${std || "<li>Continue testing to produce a standards-level recommendation.</li>"}</ol>
  `;
}

/* ---------------- Boot ---------------- */
/* ---------------- Boot ---------------- */
export function boot(){
  const gradeSel = document.getElementById("grade");
  const studentNameEl = document.getElementById("studentName");
  const parentEmailEl = document.getElementById("parentEmail");
  const consentEl = document.getElementById("consent");
  const accessCodeEl = document.getElementById("accessCode");
  const startBtn = document.getElementById("startBtn");
  const mount = document.getElementById("mount");
  const report = document.getElementById("report");

  startBtn?.addEventListener("click", async ()=>{
    const grade = Number(gradeSel?.value || 5);
    const studentName = (studentNameEl?.value || "").trim();
    const parentEmail = (parentEmailEl?.value || "").trim();
    const enteredCode = (accessCodeEl?.value || "").trim();
    const consentOk = !!consentEl?.checked || !parentEmail;

    if (parentEmail && !consentOk) {
      alert("Please confirm you have permission to email this report to a parent/guardian.");
      return;
    }

    showAccessError("");

    if (!supabase) {
      showAccessError("Setup required: Supabase not configured. Check supabase-config.js");
      return;
    }

    try {
      // ✅ Redeem BEFORE starting (single-use, prevents sharing)
      const res = await redeemAccessCode(enteredCode);
      if (!res.ok) {
        showAccessError(res.reason);
        return;
      }

      currentAccessCode = res.code;

      // start test
      initState(grade, studentName, parentEmail);
      report.innerHTML = "";
      setProgress();
      renderCurrent(mount);
    } catch (err) {
      showAccessError(err?.message || "Access code check failed.");
    }
  });
}

// ✅ self-boot so the Start handler is always attached
if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
}
